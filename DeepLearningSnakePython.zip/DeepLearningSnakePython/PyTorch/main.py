from menus import StartMenu


if __name__ == "__main__":
    start_menu = StartMenu()
    start_menu.main_menu()
